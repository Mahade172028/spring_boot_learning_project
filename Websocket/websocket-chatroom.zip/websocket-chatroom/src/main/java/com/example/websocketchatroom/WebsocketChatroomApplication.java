package com.example.websocketchatroom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsocketChatroomApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsocketChatroomApplication.class, args);
	}

}
