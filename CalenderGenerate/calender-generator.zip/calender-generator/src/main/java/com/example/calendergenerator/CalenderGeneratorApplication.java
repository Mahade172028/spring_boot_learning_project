package com.example.calendergenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalenderGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalenderGeneratorApplication.class, args);
	}

}
