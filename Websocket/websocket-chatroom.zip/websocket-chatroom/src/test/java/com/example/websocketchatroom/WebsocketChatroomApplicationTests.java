package com.example.websocketchatroom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketChatroomApplicationTests {

	@Test
	void contextLoads() {
	}

}
