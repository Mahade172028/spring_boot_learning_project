package com.example.threadprogramming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreadProgrammingApplicationTests {

	@Test
	void contextLoads() {
	}

}
